<nav class="navbar navbar-dark bg-dark fixed-top " style="padding:0;">
  <div class="container-fluid mt-2 mb-2">
  	<div class="col-lg-12">
  		<div class="col-md-1 float-left" style="display: flex;">
  			
  		</div>
      <div class="col-md-4 float-left text-white">
        <large><h4><a href="index.php?page=home">Grocery Sales and Inventory System</a></h4></large>
      </div>
	  	<div class="col-md-2 float-right text-white">
	  		<a href="ajax.php?action=logout" class="text-white"><?php echo ' Logout ' ?> <i class="fa fa-power-off"></i></a>
	    </div>
    </div>
  </div>
  
</nav>