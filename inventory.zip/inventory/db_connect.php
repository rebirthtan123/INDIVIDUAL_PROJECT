<?php 

$conn= new mysqli('localhost','root','','inventory');
?>