
<div class="container-fluid">
	<div class="col-lg-12">
		<div class="row">

        </div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
                <div class="card-header">
						<h4><b>Sales Analytic</b></h4>
				</div>
					<div class="card-body">
						<div class="chart" id="chart_container">
							<canvas id="canvasMonth" style="height: auto; width: auto;"></canvas>							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script type="text/javascript" src="assets/js/app.js"></script>